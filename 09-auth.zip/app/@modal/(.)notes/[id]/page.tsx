export { default } from "@/app/(private routes)/@modal/(.)notes/[id]/page";
