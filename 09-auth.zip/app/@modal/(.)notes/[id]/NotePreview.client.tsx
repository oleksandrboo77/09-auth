export { default } from "@/app/(private routes)/@modal/(.)notes/[id]/NotePreview.client";
