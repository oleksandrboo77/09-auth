export interface User {
  id: string;
  email: string;
  userName: string;
  photoUrl?: string;
  createdAt: string;
  updatedAt: string;
}
